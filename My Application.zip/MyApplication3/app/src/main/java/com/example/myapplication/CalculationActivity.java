package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class CalculationActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculation);


    }

    public void Calculate(View v) {


        EditText et1 = (EditText) findViewById(R.id.editTextNumberDecimal8);
        EditText et2 = (EditText) findViewById(R.id.editTextNumberDecimal9);
       // EditText et6 = (EditText) findViewById(R.id.editTextNumberDecimal10);
        EditText et3 = (EditText) findViewById(R.id.editTextNumber2);
        EditText et4 = (EditText) findViewById(R.id.editTextNumber3);
        EditText et5 = (EditText) findViewById(R.id.editTextNumber4);


        int weight = Integer.parseInt(et1.getText().toString());
        int value = Integer.parseInt(et2.getText().toString());
       // int type = Integer.parseInt(et6.getText().toString());
        int result = weight * value ;
        int result1 = (weight - 200) * value ;
        int result2 = (int) (0.025 * (result1));

        et3.setText("Total Value" + result);
        et4.setText("Zakat Payable" + result1);
        et5.setText("Total" + result2);

    }



}