package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }



    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);

        return true;


    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.about:
                // Toast.makeText(this, "This is about", Toast.LENGTH_LONG).show();
                Intent intent = new Intent (this, AboutActivity.class);
                startActivity(intent);

                break;

            case R.id.calculation:

                //Toast.makeText(this, "This is Zakat Calculation", Toast.LENGTH_LONG).show();
                Intent intent1 = new Intent(this, CalculationActivity.class);
                startActivity(intent1);

                break;

            case R.id.search:
                Toast.makeText(this, "This is search", Toast.LENGTH_LONG).show();
                break;


        }
        return super.onOptionsItemSelected(item);
    }
}


